ارشادات سريعة
1. افتح المجلد واكد ان الملف index.html موجود في الجذر.
2. لرفع إلى GitHub Pages: أنشئ repo جديد، ارفع محتويات المجلد (not the folder itself) إلى الفرع main.
3. في Settings -> Pages اختر Branch: main وFolder: / (root) ثم Save.
4. انتظر دقيقة ثم افتح الرابط https://<your-username>.github.io/<repo-name>